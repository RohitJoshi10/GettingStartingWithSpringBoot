package com.RohitSpringProject.InternalWorkingOfSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InternalWorkingOfSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
