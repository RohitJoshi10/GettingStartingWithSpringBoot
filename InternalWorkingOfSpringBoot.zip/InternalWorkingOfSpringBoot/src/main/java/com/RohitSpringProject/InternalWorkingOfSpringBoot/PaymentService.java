package com.RohitSpringProject.InternalWorkingOfSpringBoot;

public interface PaymentService {
    String pay();
}
