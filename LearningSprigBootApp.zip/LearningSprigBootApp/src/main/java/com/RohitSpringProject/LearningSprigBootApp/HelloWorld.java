package com.RohitSpringProject.LearningSprigBootApp;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloWorld {
    @GetMapping("/")
    public String Greet(){
        return "Hii Welcome to Hello World";
    }

    @GetMapping("/error")
    public String errorMessage(){
        return "Encountered an Error 💀";
    }
}
