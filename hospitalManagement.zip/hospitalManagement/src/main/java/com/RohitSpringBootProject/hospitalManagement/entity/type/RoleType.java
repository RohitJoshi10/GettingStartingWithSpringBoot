package com.RohitSpringBootProject.hospitalManagement.entity.type;

public enum RoleType {
    ADMIN,
    DOCTOR,
    PATIENT
}
