package com.RohitSpringBootProject.hospitalManagement.security;

import com.RohitSpringBootProject.hospitalManagement.dto.LoginRequestDto;
import com.RohitSpringBootProject.hospitalManagement.dto.LoginResponseDto;
import com.RohitSpringBootProject.hospitalManagement.dto.SignUpRequestDto;
import com.RohitSpringBootProject.hospitalManagement.dto.SignupResponseDto;
import com.RohitSpringBootProject.hospitalManagement.entity.Patient;
import com.RohitSpringBootProject.hospitalManagement.entity.User;
import com.RohitSpringBootProject.hospitalManagement.entity.type.AuthProviderType;
import com.RohitSpringBootProject.hospitalManagement.entity.type.RoleType;
import com.RohitSpringBootProject.hospitalManagement.repository.PatientRepository;
import com.RohitSpringBootProject.hospitalManagement.repository.UserRepository;
import jakarta.persistence.Table;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Service;

import java.util.Set;

@Service
@RequiredArgsConstructor
public class AuthService {
    // Hum login wala kaam authentication manager ko delegate krna cha rhe hai and uske pass ek mathod hai authenticate usko hum call kr denge.
    private final AuthenticationManager authenticationManager;
    private final AuthUtil authUtil;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final PatientRepository patientRepository;


    // Hume iss authenticate method mai username password wala object bhejna hai.
    public LoginResponseDto login(LoginRequestDto loginRequestDto) {
        Authentication authentication = authenticationManager.authenticate(
                // Create a token
                new UsernamePasswordAuthenticationToken(loginRequestDto.getUsername(), loginRequestDto.getPassword())
        );

        // Agr valid authentication mil gya
        User user = (User) authentication.getPrincipal();

        // Ab iss user ki help se hum token bana skte hai as LoginRequestDto mai hume jwt token he toh bhejna hai.
        // Token banane k liye ek file bana lo AuthUtil krke.
        String token = authUtil.generateAccessToken(user);
        return new LoginResponseDto(token, user.getId());


    }

    public User signUpInternal(SignUpRequestDto signupRequestDto, AuthProviderType authProviderType, String providerId){
        User user = userRepository.findByUsername(signupRequestDto.getUsername()).orElse(null);
        if(user != null) throw new IllegalArgumentException("User already exist");

        user = User.builder()
                 .username(signupRequestDto.getUsername())
                .providerId(providerId)
                .providerType(authProviderType)
                //.roles(Set.of(RoleType.PATIENT))
                .roles(signupRequestDto.getRoles()) // ye nhi krna just for demo and study purpose ki hum signup krte hai time roles bhi define kr skte hai.
                .build();
        if(authProviderType == AuthProviderType.EMAIL){
            user.setPassword(passwordEncoder.encode(signupRequestDto.getPassword()));
        }

        user = userRepository.save(user);

        Patient patient = Patient.builder()
                .name(signupRequestDto.getName())
                .email(signupRequestDto.getUsername())
                .user(user)
                .build();


        patientRepository.save(patient);
        return user;
    }

    // Login Controller
    public SignupResponseDto signup(SignUpRequestDto signupRequestDto) {
        User user = signUpInternal(signupRequestDto, AuthProviderType.EMAIL, null);
        return new SignupResponseDto(user.getId(), user.getUsername());
    }

    @Transactional
    public ResponseEntity<LoginResponseDto> handleOAuth2LoginRequest(OAuth2User oAuth2User, String registrationId) {
        // We need to find provider Type and provider id.
        AuthProviderType providerType = authUtil.getProviderTypeFromRegistration(registrationId);
        String providerId = authUtil.determineProviderIdFromOAuth2User(oAuth2User, registrationId);

        User user = userRepository.findByProviderIdAndProviderType(providerId, providerType).orElse(null);
        String email = oAuth2User.getAttribute("email");
        String name = oAuth2User.getAttribute("name");

        User emailUser = userRepository.findByUsername(email).orElse(null);
        if(user == null && emailUser == null){
            // Signup flow:
            String username = authUtil.determineUsernameFromOAuth2User(oAuth2User, registrationId, providerId);
            user = signUpInternal(new SignUpRequestDto(username, null, name, Set.of(RoleType.PATIENT)), providerType, providerId);
        } else if(user != null){
            if(email != null && !email.isBlank() && !email.equals(user.getUsername())){
                user.setUsername(email);
                userRepository.save(user);
            }
        } else {
            throw new BadCredentialsException("This email is already registered with provider " + emailUser.getProviderType());
        }

        LoginResponseDto loginResponseDto = new LoginResponseDto(authUtil.generateAccessToken(user), user.getId());
        return ResponseEntity.ok(loginResponseDto);
        // Save the provider type and provider id info with user.
        // If the user has an account: directly login
        // otherwise , first signup and then login.
    }
}


// Ye Authenticate krne k liye jayega different different AuthenticationProvide k pass let say wo gya daoAuthenticaton provider k pass
// And DaoAuthentication Provider internally UserDetailService ko call krega Jike pass do option hai ek toh InMemoryUserDetailsManager ko implement kre but wo hoga ni as humne khud ki User bana dia hai toh wo uska use krega.
