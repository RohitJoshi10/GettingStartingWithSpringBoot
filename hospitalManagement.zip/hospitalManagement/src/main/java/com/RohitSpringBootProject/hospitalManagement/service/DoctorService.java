package com.RohitSpringBootProject.hospitalManagement.service;

import com.RohitSpringBootProject.hospitalManagement.dto.DoctorResponseDto;
import com.RohitSpringBootProject.hospitalManagement.dto.OnboardDoctorRequestDto;
import com.RohitSpringBootProject.hospitalManagement.entity.Doctor;
import com.RohitSpringBootProject.hospitalManagement.entity.User;
import com.RohitSpringBootProject.hospitalManagement.entity.type.RoleType;
import com.RohitSpringBootProject.hospitalManagement.repository.DoctorRepository;
import com.RohitSpringBootProject.hospitalManagement.repository.UserRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.asm.IModelFilter;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class DoctorService {
    private final UserRepository userRepository;
    private final DoctorRepository doctorRepository;
    private final ModelMapper modelMapper;

    public List<DoctorResponseDto> getAllDoctors(){
        return doctorRepository.findAll()
                .stream()
                .map(doctor -> modelMapper.map(doctor, DoctorResponseDto.class))
                .collect(Collectors.toList());
    }

    @Transactional
    public DoctorResponseDto onBoardNewDoctor(OnboardDoctorRequestDto onboardDoctorRequestDto) {
        // Check if this user already exist or not
        User user = userRepository.findById(onboardDoctorRequestDto.getUserId()).orElseThrow();

        // Check if this user is already a doctor or not
        if(doctorRepository.existsById(onboardDoctorRequestDto.getUserId())){
            throw new IllegalArgumentException("Already a doctor");
        }

        // If it is a user but not a doctor
        Doctor doctor = Doctor.builder()
                .name(onboardDoctorRequestDto.getName())
                .specialization(onboardDoctorRequestDto.getSpecialization())
                .user(user)
                .build();

        user.getRoles().add(RoleType.DOCTOR);
        return modelMapper.map(doctorRepository.save(doctor), DoctorResponseDto.class);
    }
}
