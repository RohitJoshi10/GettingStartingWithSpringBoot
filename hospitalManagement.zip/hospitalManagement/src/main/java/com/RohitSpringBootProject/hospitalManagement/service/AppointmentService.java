package com.RohitSpringBootProject.hospitalManagement.service;

import com.RohitSpringBootProject.hospitalManagement.dto.AppointmentResponseDto;
import com.RohitSpringBootProject.hospitalManagement.dto.CreateAppointmentRequestDto;
import com.RohitSpringBootProject.hospitalManagement.entity.Appointment;
import com.RohitSpringBootProject.hospitalManagement.entity.Doctor;
import com.RohitSpringBootProject.hospitalManagement.entity.Patient;
import com.RohitSpringBootProject.hospitalManagement.repository.AppointmentRepository;
import com.RohitSpringBootProject.hospitalManagement.repository.DoctorRepository;
import com.RohitSpringBootProject.hospitalManagement.repository.PatientRepository;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.print.Doc;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AppointmentService {

    private final AppointmentRepository appointmentRepository;
    private final DoctorRepository doctorRepository;
    private final PatientRepository patientRepository;
    private final ModelMapper modelMapper;

    @Transactional
    @Secured("ROLE_PATIENT")
    public AppointmentResponseDto createNewAppointment(CreateAppointmentRequestDto createAppointmentRequestDto){
        Long doctorId = createAppointmentRequestDto.getDoctorId();
        Long patientId = createAppointmentRequestDto.getPatientId();

        Patient patient = patientRepository.findById(patientId).orElseThrow(()->new EntityNotFoundException("Patient not found with ID: " + patientId));
        Doctor doctor = doctorRepository.findById(doctorId).orElseThrow(()->new EntityNotFoundException("Doctor not found with ID: " + doctorId));

        Appointment appointment = Appointment.builder()
                .reason(createAppointmentRequestDto.getReason())
                .appointmentTime(createAppointmentRequestDto.getAppointmentTime())
                .build();

        appointment.setPatient(patient);
        appointment.setDoctor(doctor);

        patient.getAppointments().add(appointment); // to maintain consistency

        appointment = appointmentRepository.save(appointment);
        return modelMapper.map(appointment, AppointmentResponseDto.class);
    }

//    @Transactional
//    public Appointment createNewAppointment(Appointment appointment, Long doctorId, Long patientId){
//        Doctor doctor = doctorRepository.findById(doctorId).orElseThrow(()->new RuntimeException("Doctor not found with id: "+ doctorId));
//        Patient patient = patientRepository.findById(patientId).orElseThrow(()->new RuntimeException("Patient not found with id: " + patientId));
//
//        // Check for creation as koi appointment already exist nhi krna chahey as we are crating a new appointemnt with the help of doctorId and PatientId.
//        if(appointment.getId() != null) throw new IllegalArgumentException("Appointment should not have id");
//
//        // Idhr Appointment own krta hai relationship ko jidhr join column lga rheta hai relationship ko own krta hai.
//        appointment.setPatient(patient);
//        appointment.setDoctor(doctor);
//
//        patient.getAppointments().add(appointment); // Just to maintain bidirectional consistency
//
//        return appointmentRepository.save(appointment);
//
//    }

    @Transactional
    @PreAuthorize("hasAuthority('appointment:write') OR  #doctorId == authentication.principal.id")
    public Appointment reAssignAppointmentToAnotherDoctor(Long appointmentId, Long doctorId){
        Appointment appointment = appointmentRepository.findById(appointmentId).orElseThrow();
        Doctor doctor = doctorRepository.findById(doctorId).orElseThrow();
        appointment.setDoctor(doctor); // Kyuki yaha pe hum persistent state mai h because of Transactional so idhr pe update krne ki koi need nhi h. Wo dirtly checking krega and kyuki appointemnt mai humne doctor add kia h toh wo usko update kr dega
        doctor.getAppointments().add(appointment); // Just Maintaining the Bi-Directional Consistency
        return  appointment;
    }

    // EK doctor sirf apni appointments dekh skta hai dusre doctors ki nhi
    @PreAuthorize("hasRole('ADMIN') OR (hasRole('DOCTOR') AND #doctorId == authentication.principal.id)")
    public List<AppointmentResponseDto> getAllAppointmentsOfDoctor(Long doctorId){
        Doctor doctor = doctorRepository.findById(doctorId).orElseThrow();
        return doctor.getAppointments()
                .stream()
                .map(appointment -> modelMapper.map(appointment, AppointmentResponseDto.class))
                .collect(Collectors.toList());
    }
}
