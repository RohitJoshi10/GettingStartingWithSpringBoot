package com.RohitSpringBootProject.hospitalManagement.entity.type;

public enum AuthProviderType {
    GOOGLE,
    GITHUB,
    FACEBOOK,
    TWITTER,
    EMAIL
}
