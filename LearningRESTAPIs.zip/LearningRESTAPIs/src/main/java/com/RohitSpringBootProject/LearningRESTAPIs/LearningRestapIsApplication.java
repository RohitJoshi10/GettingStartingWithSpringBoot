package com.RohitSpringBootProject.LearningRESTAPIs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearningRestapIsApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearningRestapIsApplication.class, args);
	}

}
