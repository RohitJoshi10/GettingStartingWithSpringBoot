package com.RohitSpringBootProject.LearningRESTAPIs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearningRestapIsApplicationTests {

	@Test
	void contextLoads() {
	}

}
