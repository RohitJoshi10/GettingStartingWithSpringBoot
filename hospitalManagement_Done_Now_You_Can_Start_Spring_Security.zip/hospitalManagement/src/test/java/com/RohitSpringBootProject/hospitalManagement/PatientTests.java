package com.RohitSpringBootProject.hospitalManagement;

import com.RohitSpringBootProject.hospitalManagement.dto.BloodGroupCountResponseEntity;
import com.RohitSpringBootProject.hospitalManagement.entity.Patient;
import com.RohitSpringBootProject.hospitalManagement.entity.type.BloodGroupType;
import com.RohitSpringBootProject.hospitalManagement.repository.PatientRepository;
import com.RohitSpringBootProject.hospitalManagement.service.PatientService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import java.time.LocalDate;
import java.util.List;

@SpringBootTest
public class PatientTests {
    @Autowired
    private PatientRepository patientRepository;

    @Autowired
    private PatientService patientService;

    @Test
    public void testPatientRepository(){
//       List<Patient> patientList1 = patientRepository.findAll();
        List<Patient> patientList1 = patientRepository.findAllPatientWithAppointment();
        System.out.println(patientList1);
    }

    @Test
    public void testTransactionMethods(){
//        Patient patient = patientService.getPatientById(1L);
//        System.out.println(patient);

        Patient patient1 = patientRepository.findByName("Niharika Dhyani");
        Patient  patient2 = patientRepository.findByBirthDateOrEmail(LocalDate.parse("1995-11-10"), "priya@gmail.com");
        List<Patient> patient3 = patientRepository.findByBirthDateBetween(LocalDate.parse("1997-12-30"), LocalDate.parse("2002-05-21"));
        List<Patient> patient4 = patientRepository.findByNameContainingOrderByIdDesc("r");
        List<Patient> patient5 = patientRepository.findByBloodGroup(BloodGroupType.A_POSITIVE);
        List<Patient> patient6 = patientRepository.findByBornAfterDate(LocalDate.of(1997,12,30));
        List<Object[]> bloodGroupList = patientRepository.countEachBloodGroupType();
        List<Patient> patientList = patientRepository.findAllPatients();
        List<BloodGroupCountResponseEntity> bloodGroupListt = patientRepository.countEachBloodGroupTypee();
        int  rowsUpdated = patientRepository.updateNameWithId("Ammit Verma", 1L);



        System.out.println(patient1);
        System.out.println(patient2);
        System.out.println(patient3);
        System.out.println(patient4);
        System.out.println(patient5);
        System.out.println(patient6);

        for(Object[] objects : bloodGroupList){
            System.out.println(objects[0] + " " + objects[1]);
        }

        System.out.println(patientList);
        System.out.println(rowsUpdated);

        for(BloodGroupCountResponseEntity bloodGroupCountResponseEntity : bloodGroupListt){
            System.out.println(bloodGroupCountResponseEntity);
        }


        // Pagination
        Page<Patient> patientLists = patientRepository.findAllPatients(PageRequest.of(0, 2, Sort.by("name")));
        for(Patient patient: patientLists) {
            System.out.println(patient);
        }
    }
}
