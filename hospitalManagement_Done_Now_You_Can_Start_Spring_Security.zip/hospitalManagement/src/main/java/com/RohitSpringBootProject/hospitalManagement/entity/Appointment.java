package com.RohitSpringBootProject.hospitalManagement.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class Appointment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private LocalDateTime appointmentTime;

    @Column(length = 500)
    private String reason;

    @ManyToOne
    @ToString.Exclude // Waise hum idhr pe Json Ignore kr skte thy
    @JoinColumn(name = "patient_id", nullable = false) // patient is required and not nullable
    private Patient patient; // NO need to define any cascading here as mai ye nhi chata ki jab bhi appointment bane toh ek naya patient bn jaye so we will not define any cascading here.

    @ManyToOne(fetch = FetchType.LAZY)
    @ToString.Exclude
    @JoinColumn(nullable = false)
    private Doctor doctor;
}

// Cascade type parent k ander lagea na ki child k ander. Patient(parent) Appointment(child) agr child k ander laga dia toh
// Appointment ko delete kroge toh uske sath associated parent bhi delete ho jayega CASCADEType ALL mai and agr multiple. And agr wo patient multiple appointment k sath attached hai toh error mil jayega.