package com.RohitSpringBootProject.hospitalManagement.entity;

import com.RohitSpringBootProject.hospitalManagement.entity.type.BloodGroupType;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@ToString
@Getter
@Setter
@Table(

        uniqueConstraints = {
                // @UniqueConstraint(name = "unique_patient_email", columnNames = {"email"}),
                @UniqueConstraint(name = "unique_patient_name_birthdate",columnNames = {"name", "birthDate"})
        },
        indexes = {
                @Index(name = "idx_patient_birth_date", columnList = "birthDate, email")
        }
)
public class Patient {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name", nullable = false, length = 40)
    private String name;

    // @ToString.Exclude
    private LocalDate birthDate;

    @Column(unique = true, nullable = false)
    private String email;

    @ToString.Exclude
    private String gender;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime createAt;

    @Enumerated(EnumType.STRING)
    private BloodGroupType bloodGroup;

//    @OneToOne(cascade = {CascadeType.MERGE, CascadeType.PERSIST}) // Ye bas save and update k liye tha patient save ya update hoga toh insurance bhi hoga uske sath as Parent is Patient.
    @OneToOne(cascade = {CascadeType.ALL}, orphanRemoval = true) // Ab Patient k remove hone pe insurance delete nhi hoga.
    @JoinColumn(name = "patient_insurance_id") // Owning side
    private Insurance insurance; // This is a Join Column

    @OneToMany(mappedBy = "patient", cascade = {CascadeType.REMOVE}, orphanRemoval = true, fetch = FetchType.EAGER) // MappedBy islye use kia taki isme ek column na create ho jaye appointement ka jo ki foreign key ki trhe act krega but foreign key wala toh hum already he define kr chuke hai appointment mai islye idhr ye krre hai tak extra column na create ho.
    private List<Appointment> appointments = new ArrayList<>(); // inverse side

}

//orphanRemoval = true means
// patient.getAppointment().remove(appointment);