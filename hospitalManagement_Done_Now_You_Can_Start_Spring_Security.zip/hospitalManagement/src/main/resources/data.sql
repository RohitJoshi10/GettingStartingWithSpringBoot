INSERT INTO patient (name, birth_date, email, gender, blood_group)
VALUES
  ('Niharika Dhyani', '2002-05-21', 'niharika@gmail.com', 'Female', 'O_POSITIVE'),
  ('Priya Sharma', '1995-11-10', 'priya@gmail.com', 'Female', 'A_POSITIVE'),
  ('Amit Verma', '2000-02-14', 'amit@gmail.com', 'Male', 'A_POSITIVE'),
  ('Sneha Kapoor', '1993-08-05', 'sneha@gmail.com', 'Female', 'AB_POSITIVE'),
  ('Rahul Mehta', '1997-12-30', 'rahul@gmail.com', 'Male', 'O_POSITIVE');


INSERT INTO doctor(name, specialization, email)
VALUES
     ('Dr. Rakesh Mehta', 'Cardiology', 'rakesh.mehta@gmail.com'),
     ('Dr. Sneha Kapoor', 'Dermatology', 'sneha.kapoor@gmail.com'),
     ('Dr. Arjun Nair', 'Orthopedics', 'arjun.nair@gmail.com');

INSERT INTO appointment (appointment_time, reason, doctor_id, patient_id)
VALUES
    ('2025-07-01 10:30:00', 'General Checkup', 1, 2),
    ('2025-07-02 11:00:00', 'Skin Rash', 2, 2),
    ('2025-07-03 09:45:00', 'Knee Pain', 3, 3),
    ('2025-07-04 14:00:00', 'Follow-up Visit', 1,1),
    ('2025-07-05 16:15:00', 'Consultation', 1, 4),
    ('2025-07-05 08:30:00', 'Allergy Treatment', 2, 5);